#!/usr/bin/env bash
set -euo pipefail
mgbfs_root=/workspace/dev41-results/bench8-repeat
mgbfs_archive=/workspace/dev41-results/bench8-repeat-repeat.tgz
finish(){
 mgbfs_rc=$?
 trap - EXIT
 printf '%s\n' "$mgbfs_rc" > "$mgbfs_root/exit-code.txt"
 tar -czf "$mgbfs_archive" -C "$mgbfs_root" . || mgbfs_rc=71
 printf 'BENCH8_DONE code=%s\n' "$mgbfs_rc"
 exit "$mgbfs_rc"
}
trap finish EXIT
exec 9>/workspace/dev41-results/gpu-exclusive.lock
flock -n 9 || { echo GPU_LOCK_BUSY; exit 20; }
export MGBFS_NATIVE_CACHE=/workspace/dev41-sm86/cache MGBFS_NATIVE_OFFLINE=1
export MGBFS_BENCH_REPO=/workspace/dev41-repo
unset PYTHONPATH MGBFS_SEGMENT_MAX_RANK_STATES MGBFS_SEGMENT_STORAGE_BUDGET_BYTES MGBFS_SEGMENT_BITMAP_OWNER_PAGE MGBFS_SEGMENT_TEST_HOST_TIMEOUT_MS MGBFS_SEGMENT_LAYER_STATS || true
MGBFS_EXECUTABLE=$(/workspace/dev41-venv/bin/python -c 'import json;print(json.load(open("/workspace/dev41-results/cache-prepared.json"))["binary"])')
export MGBFS_EXECUTABLE
mgbfs_bundle="$(dirname "$(dirname "$MGBFS_EXECUTABLE")")"
export MGBFS_BENCH_CUDA_LIBRARY="$mgbfs_bundle/lib/libmgbfs_cuda.so"
export LD_LIBRARY_PATH="$mgbfs_bundle/lib:${LD_LIBRARY_PATH:-}"
{
 date -u +%FT%TZ
 git -C "$MGBFS_BENCH_REPO" rev-parse HEAD
 sha256sum "$MGBFS_EXECUTABLE" "$MGBFS_BENCH_CUDA_LIBRARY" /workspace/dev41-sm86/bench/benchmark_segmented_eight.py
 nvidia-smi --query-gpu=index,name,uuid,memory.total,driver_version --format=csv,noheader
 nvidia-smi topo -m
} > "$mgbfs_root/environment.txt" 2>&1
idle(){
 local mgbfs_busy
 for _ in $(seq 1 20); do
  mgbfs_busy="$(nvidia-smi --query-compute-apps=pid --format=csv,noheader,nounits)" || return 1
  [ -z "$(printf '%s' "$mgbfs_busy" | tr -d '[:space:]')" ] && return 0
  sleep 1
 done
 printf 'GPU_BUSY %s\n' "$mgbfs_busy"
 return 1
}
run_case(){
 local mgbfs_label="$1" mgbfs_backend="$2" mgbfs_strategy="$3" mgbfs_mode="$4" mgbfs_case="$mgbfs_root/$1"
 mkdir -p "$mgbfs_case"
 printf 'RUNNING\n' > "$mgbfs_case/status.txt"
 idle || { printf 'GPU_BUSY\n' > "$mgbfs_case/status.txt";return 21; }
 if MGBFS_SEGMENT_BATCH_RECOVERY="$mgbfs_mode" timeout --kill-after=10s 1200s /workspace/dev41-venv/bin/python -u /workspace/dev41-sm86/bench/benchmark_segmented_eight.py --backend "$mgbfs_backend" --strategy "$mgbfs_strategy" --n 12 --repeat 1 --base "$mgbfs_case" > "$mgbfs_case/run.log" 2>&1; then
  idle || { printf 'POST_GPU_BUSY\n' > "$mgbfs_case/status.txt";return 22; }
  printf 'COMPLETE\n' > "$mgbfs_case/status.txt"
 else
  mgbfs_case_rc=$?
  printf 'FAILED %s\n' "$mgbfs_case_rc" > "$mgbfs_case/status.txt"
  return "$mgbfs_case_rc"
 fi
 echo "PASS $mgbfs_label"
}
run_case bitmap-on-2 permutation_bitmap atomic 1
run_case bitmap-off-2 permutation_bitmap atomic 0
run_case bitmap-off-3 permutation_bitmap atomic 0
run_case bitmap-on-3 permutation_bitmap atomic 1
echo ALL_REPEATS_COMPLETE
