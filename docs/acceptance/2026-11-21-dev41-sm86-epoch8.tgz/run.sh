#!/usr/bin/env bash
set -uo pipefail
exec 9>/workspace/dev41-results/gpu-exclusive.lock
if ! flock -n 9; then echo GPU_LOCK_BUSY; exit 20; fi
mgbfs_busy="$(nvidia-smi --query-compute-apps=pid --format=csv,noheader,nounits)"
if [ -n "$(printf '%s' "$mgbfs_busy" | tr -d '[:space:]')" ]; then printf 'GPU_BUSY %s\n' "$mgbfs_busy";exit 21;fi
export MGBFS_NATIVE_CACHE=/workspace/dev41-sm86/cache MGBFS_NATIVE_OFFLINE=1 MGBFS_TEST_WORLD=8
unset PYTHONPATH || true
MGBFS_EXECUTABLE=$(/workspace/dev41-venv/bin/python -c 'import json;print(json.load(open("/workspace/dev41-results/cache-prepared.json"))["binary"])')
export MGBFS_EXECUTABLE
mgbfs_bundle="$(dirname "$(dirname "$MGBFS_EXECUTABLE")")"
export LD_LIBRARY_PATH="$mgbfs_bundle/lib:${LD_LIBRARY_PATH:-}"
mgbfs_rc=0
timeout --kill-after=10s 1200s /workspace/dev41-venv/bin/python -u /workspace/dev41-source/tests/segmented_comm_epoch_fault_gpu.py > /workspace/dev41-results/epoch8/test.log 2>&1 || mgbfs_rc=$?
mkdir -p /workspace/dev41-results/epoch8/evidence
while IFS= read -r -d '' mgbfs_path; do cp -a "$mgbfs_path" /workspace/dev41-results/epoch8/evidence/ || mgbfs_rc=70; done < <(find /workspace -maxdepth 1 -type d -name 'segmented-epoch-8gpu-*' -print0)
printf '%s\n' "$mgbfs_rc" > /workspace/dev41-results/epoch8/exit-code.txt
tar -czf /workspace/dev41-results/epoch8.tgz -C /workspace/dev41-results/epoch8 . || exit 71
echo "EPOCH8_DONE code=$mgbfs_rc"
exit "$mgbfs_rc"
