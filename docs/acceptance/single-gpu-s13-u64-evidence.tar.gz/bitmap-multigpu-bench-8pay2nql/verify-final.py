import json, pathlib, csv, hashlib
root=pathlib.Path('/workspace/bitmap-multigpu-bench-8pay2nql/0-exact')
r=json.loads((root/'rank-0/report.json').read_text())
s=json.loads((root/'rank-0/states.json').read_text())
n=13
reverse=tuple(reversed(range(n)))
previous=[]
for i in range(n-1):
 a=list(reverse);a[i],a[i+1]=a[i+1],a[i];previous.append(tuple(a))
assert r['status']=='COMPLETE'
assert sum(r['layer_sizes'])==6227020800 and len(r['layer_sizes'])==79
assert sorted(map(tuple,s['current']))==[reverse]
assert sorted(map(tuple,s['previous_small']))==sorted(previous)
m=[]
for row in csv.reader((root/'gpu.csv').read_text().splitlines()):
 if len(row)>=3:
  try:m.append(float(row[2].strip()))
  except ValueError:pass
assert m
summary={'status':r['status'],'states':sum(r['layer_sizes']),'layers':len(r['layer_sizes']),'bfs_seconds':r['bfs_seconds'],'peak_live_rows':r['segment_memory']['peak_live_rows'],'sampled_peak_mib':max(m),'samples':len(m),'final_two_full_sets_verified':True,'final_size':len(s['current']),'previous_size':len(s['previous_small']),'state_file_sha256':hashlib.sha256((root/'rank-0/states.json').read_bytes()).hexdigest(),'report_sha256':hashlib.sha256((root/'rank-0/report.json').read_bytes()).hexdigest()}
(root/'independent-check.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary))
