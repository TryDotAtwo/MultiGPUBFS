import ctypes, json, os, subprocess, sys, time, traceback
from pathlib import Path

if len(sys.argv)>1 and sys.argv[1]=='hog':
    c=ctypes.CDLL(sys.argv[2])
    c.cudaSetDevice.argtypes=[ctypes.c_int]; c.cudaSetDevice.restype=ctypes.c_int
    c.cudaMemGetInfo.argtypes=[ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(ctypes.c_size_t)]; c.cudaMemGetInfo.restype=ctypes.c_int
    c.cudaMalloc.argtypes=[ctypes.POINTER(ctypes.c_void_p),ctypes.c_size_t]; c.cudaMalloc.restype=ctypes.c_int
    c.cudaFree.argtypes=[ctypes.c_void_p]; c.cudaFree.restype=ctypes.c_int
    allocated=[]
    try:
        for device in range(2):
            assert c.cudaSetDevice(device)==0
            free=ctypes.c_size_t(); total=ctypes.c_size_t()
            assert c.cudaMemGetInfo(ctypes.byref(free),ctypes.byref(total))==0
            before=free.value; size=before-3*1024**3
            assert size>0,(device,before)
            ptr=ctypes.c_void_p(); rc=c.cudaMalloc(ctypes.byref(ptr),size)
            assert rc==0,(device,rc,size)
            allocated.append((device,ptr))
            assert c.cudaMemGetInfo(ctypes.byref(free),ctypes.byref(total))==0
            print(json.dumps({'device':device,'total':total.value,'free_before':before,'hog_bytes':size,'free_after':free.value}),flush=True)
        print('HOG_READY',flush=True)
        while True: time.sleep(10)
    finally:
        for device,ptr in allocated:
            c.cudaSetDevice(device);c.cudaFree(ptr)
    sys.exit(0)

from multigpubfs import GraphDefinition
from multigpubfs.launch import run_graph
from multigpubfs.native_distribution import native_runtime
import multigpubfs
root=Path('/workspace/real-vram-pressure');root.mkdir(parents=True,exist_ok=True)
native,env=native_runtime()
env['NCCL_P2P_DISABLE']='1'
env['MGBFS_SEGMENT_EXACT_EXCHANGE']='1'
runtime=Path(native).parent.parent/'lib/libcudart.so.12'
assert runtime.is_file()
print(json.dumps({'package':multigpubfs.__file__,'native':native,'cudart':str(runtime)}),flush=True)
f=(root/'hog.log').open('w')
hog=subprocess.Popen([sys.executable,__file__,'hog',str(runtime)],stdout=f,stderr=subprocess.STDOUT,env=env)
try:
    for _ in range(60):
        time.sleep(1);f.flush()
        contents=(root/'hog.log').read_text()
        if hog.poll() is not None: raise RuntimeError('HOG_EXIT '+str(hog.returncode)+' '+contents)
        if 'HOG_READY' in contents:break
    else: raise RuntimeError('HOG_TIMEOUT')
    print(contents,flush=True)
    n=13;gens=[]
    for i in range(n-1):
        p=list(range(n));p[i],p[i+1]=p[i+1],p[i];gens.append(p)
    graph=GraphDefinition.permutation(gens,list(range(n)))
    oracle=[1]
    for degree in range(1,n+1):
        nxt=[0]*(len(oracle)+degree-1)
        for i,v in enumerate(oracle):
            for j in range(degree):nxt[i+j]+=v
        oracle=nxt
    results=[]
    for mode in ('segmented','permutation_bitmap'):
        print('PRESSURE_START '+mode,flush=True);start=time.monotonic()
        out=root/mode
        try:
            result=run_graph(graph,out,devices=[0,1],shards=4,autotune=False,
                executable=native,_native_env=env,memory_backend=mode,
                memory_preset='max_capacity',segment_rows=1<<20,
                max_seconds=240,_batch=2048)
            sizes=result['layer_sizes']
            assert sizes and sizes==oracle[:len(sizes)],(mode,'layer mismatch')
            states=json.loads((out/'states.json').read_text())
            depth=len(sizes)-1
            for key,d in (('current',depth),('previous_small',depth-1)):
                for state in states.get(key,[]):
                    assert sorted(state)==list(range(n)),(mode,key,'permutation')
                    inv=sum(state[i]>state[j] for i in range(n) for j in range(i+1,n))
                    assert inv==d,(mode,key,inv,d)
            record={'mode':mode,'status':result['status'],'reason':result.get('reason'),
                'depth':depth,'layers':len(sizes),'states_in_complete_layers':sum(sizes),
                'bfs_seconds':result.get('bfs_seconds'),'wall_seconds':time.monotonic()-start,
                'sample_sizes':{k:len(states.get(k,[])) for k in ('current','previous_small')},
                'segment_memory_by_rank':result.get('segment_memory_by_rank')}
            results.append(record);(root/'result.json').write_text(json.dumps(results,indent=2))
            print('PRESSURE_RESULT '+json.dumps(record),flush=True)
        except Exception:
            traceback.print_exc(); print('PRESSURE_ERROR '+mode,flush=True)
            (root/('error-'+mode+'.txt')).write_text(traceback.format_exc())
    print('PRESSURE_TEST_FINISHED '+str(root),flush=True)
finally:
    hog.terminate()
    try:hog.wait(timeout=15)
    except subprocess.TimeoutExpired:hog.kill();hog.wait()
    f.close()
