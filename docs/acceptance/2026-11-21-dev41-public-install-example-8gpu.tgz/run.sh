#!/usr/bin/env bash
set -euo pipefail
mgbfs_dest=/workspace/dev41-results/public-check
finish(){
 mgbfs_rc=$?
 trap - EXIT
 printf '%s\n' "$mgbfs_rc" > "$mgbfs_dest/exit-code.txt"
 tar --exclude='./cache' -czf /workspace/dev41-results/public-install-8gpu.tgz -C "$mgbfs_dest" . || mgbfs_rc=71
 echo "PUBLIC_INSTALL_DONE code=$mgbfs_rc"
 exit "$mgbfs_rc"
}
trap finish EXIT
exec 9>/workspace/dev41-results/gpu-exclusive.lock
flock -n 9 || { echo GPU_LOCK_BUSY; exit 20; }
for i in $(seq 1 30);do
 v="$(nvidia-smi --query-compute-apps=pid --format=csv,noheader,nounits)"
 [ -z "$(printf '%s' "$v" | tr -d '[:space:]')" ] && break
 [ "$i" -lt 30 ] || { echo "GPU_BUSY $v"; exit 21; }
 sleep 1
done
unset PYTHONPATH MGBFS_NATIVE_OFFLINE MGBFS_SEGMENT_MAX_RANK_STATES MGBFS_SEGMENT_STORAGE_BUDGET_BYTES MGBFS_SEGMENT_BITMAP_OWNER_PAGE MGBFS_SEGMENT_TEST_HOST_TIMEOUT_MS MGBFS_SEGMENT_LAYER_STATS || true
export MGBFS_NATIVE_CACHE="$mgbfs_dest/cache"
python3 -m venv --system-site-packages /workspace/dev41-public-venv
/workspace/dev41-public-venv/bin/python -m pip install --upgrade "multigpubfs[cayleypy] @ https://github.com/TryDotAtwo/MultiGPUBFS/releases/download/native-pip-20261121-v41/multigpubfs-0.2.0.dev41-py3-none-any.whl"
test ! -e "$MGBFS_NATIVE_CACHE"
timeout --kill-after=10s 1200s /workspace/dev41-public-venv/bin/python -u "$mgbfs_dest/smoke.py"
CUDA_VISIBLE_DEVICES='' MGBFS_NATIVE_OFFLINE=1 /workspace/dev41-public-venv/bin/python -m multigpubfs prefetch --sm 86 --cache "$MGBFS_NATIVE_CACHE" --json > "$mgbfs_dest/offline-prefetch.json"
/workspace/dev41-public-venv/bin/python -c 'import json;d=json.load(open("/workspace/dev41-results/public-check/offline-prefetch.json"));assert d["status"]=="PREFETCHED" and d["gpu_accessed"] is False and d["downloaded_bytes"]==0,d'
du -sh "$MGBFS_NATIVE_CACHE" > "$mgbfs_dest/cache-size.txt"
echo PUBLIC_GITHUB_INSTALL_AND_CACHE_PASS
