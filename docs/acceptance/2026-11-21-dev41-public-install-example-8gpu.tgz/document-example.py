from cayleypy import CayleyGraph, PermutationGroups
from multigpubfs import NativeOptions, enable_native, persistent_graph_workers

enable_native(NativeOptions(
    memory_backend="segmented24",   # alternative for supported permutation actions: "permutation_bitmap"
    memory_preset="balanced",       # alternative: "max_capacity"
    segment_strategy="warp",        # alternatives: "atomic", "batch"
    devices=None,                   # all visible GPUs; or tuple(range(8)) if eight are visible
))

with persistent_graph_workers():
    for n in (4, 5):
        graph = CayleyGraph(PermutationGroups.coxeter(n), device="cpu")
        result = graph.bfs()
        print(n, result.report["status"], result.layer_sizes, result.output)
        if result.bfs_completed:
            print("diameter:", result.diameter())
