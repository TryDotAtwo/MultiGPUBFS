#!/usr/bin/env bash
set -euo pipefail
mgbfs_dest=/workspace/dev41-results/public-check
finish(){
 rc=$?
 trap - EXIT
 printf '%s\n' "$rc" > "$mgbfs_dest/document-example-exit.txt"
 tar --exclude='./cache' -czf /workspace/dev41-results/public-install-and-example-8gpu.tgz -C "$mgbfs_dest" . || rc=71
 echo "DOCUMENT_EXAMPLE_DONE code=$rc"
 exit "$rc"
}
trap finish EXIT
exec 9>/workspace/dev41-results/gpu-exclusive.lock
flock 9
test "$(cat "$mgbfs_dest/exit-code.txt")" = 0
export MGBFS_NATIVE_CACHE="$mgbfs_dest/cache" MGBFS_NATIVE_OFFLINE=1
unset PYTHONPATH MGBFS_SEGMENT_MAX_RANK_STATES MGBFS_SEGMENT_STORAGE_BUDGET_BYTES MGBFS_SEGMENT_BITMAP_OWNER_PAGE MGBFS_SEGMENT_TEST_HOST_TIMEOUT_MS MGBFS_SEGMENT_LAYER_STATS || true
cd "$mgbfs_dest"
timeout --kill-after=10s 1200s /workspace/dev41-public-venv/bin/python -u "$mgbfs_dest/document-example.py" > "$mgbfs_dest/document-example.log" 2>&1
grep -F '4 COMPLETE [1, 3, 5, 6, 5, 3, 1]' "$mgbfs_dest/document-example.log"
grep -F '5 COMPLETE [1, 4, 9, 15, 20, 22, 20, 15, 9, 4, 1]' "$mgbfs_dest/document-example.log"
grep -F 'diameter: 6' "$mgbfs_dest/document-example.log"
grep -F 'diameter: 10' "$mgbfs_dest/document-example.log"
echo DOCUMENT_EXAMPLE_PASS
