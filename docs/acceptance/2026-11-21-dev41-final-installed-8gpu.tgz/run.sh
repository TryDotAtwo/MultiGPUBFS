#!/usr/bin/env bash
set -euo pipefail
mgbfs_dest=/workspace/dev41-results/final-sm86
finish(){
 mgbfs_rc=$?
 trap - EXIT
 printf '%s\n' "$mgbfs_rc" > "$mgbfs_dest/exit-code.txt"
 tar -czf /workspace/dev41-results/final-installed-8gpu.tgz -C "$mgbfs_dest" . || mgbfs_rc=71
 echo "FINAL_INSTALLED_DONE code=$mgbfs_rc"
 exit "$mgbfs_rc"
}
trap finish EXIT
exec 9>/workspace/dev41-results/gpu-exclusive.lock
flock 9
for i in $(seq 1 30);do
 v="$(nvidia-smi --query-compute-apps=pid --format=csv,noheader,nounits)"
 [ -z "$(printf '%s' "$v" | tr -d '[:space:]')" ] && break
 [ "$i" -lt 30 ] || { echo "GPU_BUSY $v"; exit 20; }
 sleep 1
done
export MGBFS_NATIVE_CACHE=/workspace/dev41-sm86/cache MGBFS_NATIVE_OFFLINE=1
unset PYTHONPATH MGBFS_SEGMENT_MAX_RANK_STATES MGBFS_SEGMENT_STORAGE_BUDGET_BYTES MGBFS_SEGMENT_BITMAP_OWNER_PAGE MGBFS_SEGMENT_TEST_HOST_TIMEOUT_MS MGBFS_SEGMENT_LAYER_STATS || true
/workspace/dev41-venv/bin/python -m pip install --no-deps --force-reinstall "$mgbfs_dest/multigpubfs-0.2.0.dev41-py3-none-any.whl"
CUDA_VISIBLE_DEVICES='' /workspace/dev41-venv/bin/python -m multigpubfs.prefetch --sm 86 --cache "$MGBFS_NATIVE_CACHE" --json > "$mgbfs_dest/offline-prefetch.json"
/workspace/dev41-venv/bin/python -c 'import json;d=json.load(open("/workspace/dev41-results/final-sm86/offline-prefetch.json"));assert d["status"]=="PREFETCHED" and d["gpu_accessed"] is False and d["downloaded_bytes"]==0,d'
timeout --kill-after=10s 900s /workspace/dev41-venv/bin/python -u "$mgbfs_dest/smoke.py"
