import hashlib, importlib.metadata, json, os
from pathlib import Path
import torch
import multigpubfs
from multigpubfs.native_distribution import native_runtime
from multigpubfs.cayleypy_backend import NativeOptions
from multigpubfs.generic_session import persistent_graph_workers
from cayleypy import CayleyGraph, PermutationGroups

def sha(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(1<<20),b''): h.update(b)
    return h.hexdigest()

def mahonian(n):
    a=[1]
    for k in range(1,n+1):
        b=[0]*(len(a)+k-1)
        for i,x in enumerate(a):
            for j in range(k): b[i+j]+=x
        a=b
    return a

root=Path('/workspace/dev41-results/final-sm86')
index=Path(multigpubfs.__file__).with_name('native_assets.json')
assert index.read_bytes()==(root/'native-assets.json').read_bytes()
exe,env=native_runtime()
library=Path(exe).parent.parent/'lib/libmgbfs_cuda.so'
assert sha(exe)=='10cb2e53915b9e8936582889445eed263cd6c370ab877aae0ee628fd8f2da687'
assert sha(library)=='ca4fba4419120aaa4a37123e56faedbb91c8e4b58e263481e9a15b517c43d908'
manifest=json.loads((Path(exe).parent.parent/'manifest.json').read_text())
assert manifest['native_delivery']['selected_component']=='cuda-sm86'
assert torch.cuda.device_count()==8
assert importlib.metadata.version('multigpubfs')=='0.2.0.dev41'
root_out=root/'api';root_out.mkdir(exist_ok=True)
rows=[]
multigpubfs.enable_native(recovery=False)
try:
    with persistent_graph_workers() as pool:
        expected_pids=None
        for n,backend,strategy,preset in [
            (4,'segmented24','warp','balanced'),
            (4,'permutation_bitmap','atomic','max_capacity'),
            (4,'segmented24','batch','max_capacity'),
            (4,'permutation_bitmap','batch','balanced'),
        ]:
            graph=CayleyGraph(PermutationGroups.coxeter(n),device='cpu')
            opts=NativeOptions(output_root=root_out,devices=tuple(range(8)),autotune=False,
                    memory_backend=backend,segment_strategy=strategy,memory_preset=preset,segment_rows=64)
            result=graph.bfs(native_options=opts)
            assert result.bfs_completed and result.layer_sizes==mahonian(n),result.report
            wanted='EXPERIMENTAL_SEGMENTED24' if backend=='segmented24' else 'EXPERIMENTAL_PERMUTATION_BITMAP'
            assert result.report['backend']==wanted,result.report
            assert result.report['segment_strategy']==strategy,result.report
            pids=[w.process.pid for w in pool.workers]
            assert len(pids)==8 and len(set(pids))==8,pids
            if expected_pids is None: expected_pids=pids
            assert pids==expected_pids,(pids,expected_pids)
            for pid in pids:
                assert str(library) in Path('/proc/%s/maps'%pid).read_text(),(pid,str(library))
            row={'n':n,'backend':backend,'strategy':strategy,'preset':preset,
                 'layers':result.layer_sizes,'pids':pids,'status':'PASS'}
            rows.append(row)
            print('API_PASS '+json.dumps(row),flush=True)
finally:
    multigpubfs.disable_native()
receipt={'status':'PASS','package':importlib.metadata.version('multigpubfs'),
         'native_sha256':sha(exe),'cuda_library_sha256':sha(library),
         'index_id':manifest['native_delivery']['index_id'],'devices':torch.cuda.device_count(),
         'rows':rows,'scope':'SM86 exact packaged files; S4 layer counts, persistent same workers'}
(root/'installed-8gpu-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('FINAL_INSTALLED_8GPU_PASS',flush=True)
