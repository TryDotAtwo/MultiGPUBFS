"""Launch a validated JSON Cayley action using the installed native runtime."""
import argparse,json,sys
from pathlib import Path
from .graph_definition import GraphDefinition
from .launch import run_graph

def main(argv=None):
 argv=list(sys.argv[1:] if argv is None else argv)
 if argv and argv[0]=='setup':
  from .cluster_setup import main as setup_main
  return setup_main(argv[1:])
 if argv and argv[0]=='prefetch':
  from .prefetch import main as prefetch_main
  return prefetch_main(argv[1:])
 if argv and argv[0]=='doctor':
  from .diagnostics import main as doctor_main
  return doctor_main(argv[1:])
 parser=argparse.ArgumentParser(description='Exact GPU BFS for CayleyPy permutation and matrix actions. Defaults: all visible GPUs, measured startup tuning and compact terminal retention.')
 parser.epilog='Service commands: multigpubfs prefetch --help; multigpubfs doctor --help.'
 parser.add_argument('definition',help='Schema2 JSON file, or Family.constructor with --catalog')
 parser.add_argument('--catalog',action='store_true',help='Resolve an exact public CayleyPy constructor name without evaluated source')
 parser.add_argument('--catalog-args',help='JSON positional argument list for the constructor')
 parser.add_argument('--catalog-kwargs',help='JSON keyword argument object for the constructor')
 parser.add_argument('output',type=Path,help='New result directory')
 parser.add_argument('--devices',help='Comma-separated local GPU IDs; omitted uses all visible GPUs')
 parser.add_argument('--seconds',type=int,default=None,help='Optional work budget in seconds; omitted or 0 runs until complete or resource stop')
 parser.add_argument('--capacity',type=int,help='Optional per-rank capacity, checked against actual free VRAM')
 parser.add_argument('--backend',choices=['auto','generic','shard_ab_hash','shard_ab_sort_merge'],default='auto')
 parser.add_argument('--memory-backend',choices=['legacy','segmented','segmented32','segmented24','permutation_bitmap'],default='legacy',help='Select BFS state storage; segmented and permutation_bitmap are experimental')
 parser.add_argument('--segment-rows',type=int,default=1<<32,help='Maximum states per segment bank (1..4294967296; default 4294967296)')
 parser.add_argument('--memory-preset',choices=['balanced','max_capacity'],default='balanced',help='Choose measured speed or a memory-capacity-oriented segmented/bitmap profile')
 parser.add_argument('--peer-transport',choices=['auto','host','lsa'],default='auto')
 parser.add_argument('--shards',type=int,help='Manual general-backend shard count; disables profile selection')
 parser.add_argument('--transport',choices=['auto','full','parent'],default='auto')
 parser.add_argument('--candidate-order',choices=['auto','none','radix'],default='auto')
 parser.add_argument('--no-autotune',action='store_true')
 args=parser.parse_args(argv)
 try:
  if args.catalog:
   from .catalog import from_catalog
   graph=from_catalog(args.definition,args=json.loads(args.catalog_args) if args.catalog_args is not None else None,kwargs=json.loads(args.catalog_kwargs) if args.catalog_kwargs is not None else None)
  else:
   if args.catalog_args is not None or args.catalog_kwargs is not None:raise ValueError('CATALOG_ARGUMENTS_REQUIRE_CATALOG')
   graph=GraphDefinition.from_dict(json.loads(Path(args.definition).read_text(encoding='utf-8')))
  devices=None if args.devices is None else [int(v) for v in args.devices.split(',')]
  report=run_graph(graph,args.output,devices=devices,max_seconds=args.seconds,capacity=args.capacity,backend=args.backend,memory_backend=args.memory_backend,segment_rows=args.segment_rows,memory_preset=args.memory_preset,peer_transport=args.peer_transport,shards=args.shards,transport=args.transport,candidate_order=args.candidate_order,autotune=not args.no_autotune)
 except (OSError,ValueError,RuntimeError,TypeError) as error:
  print(str(error),file=sys.stderr);return 1
 print(json.dumps(report,sort_keys=True));return 0
